//
//  ViewController.swift
//  OnxOrdersDelivery
//
//  Created by PHANTOM X on 06/02/2025.
//

import UIKit

class ViewController: UIViewController {


    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

