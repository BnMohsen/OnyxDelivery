//
//  main.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 18/02/2025.
//

import Foundation
import UIKit

UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, NSStringFromClass(TimerUIApplication.self), NSStringFromClass(AppDelegate.self))
