//
//  OrdersNewViewController.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//



import UIKit


struct MessageGetItemsValue: Encodable {

    let Value: MessageGetItems
    
}

struct MessageGetItems: Encodable {

    let P_DLVRY_NO: String
    let P_LANG_NO: String
    let P_BILL_SRL: String
    let P_PRCSSD_FLG: String
    
}

class OrdersNewViewController: UITableViewController {

    let theURL: String = "https://mdev.yemensoft.net:473/"
    
    var orders = Array<Dictionary<String, Any>>()
    var newOrders = Array<Dictionary<String, Any>>()
    var othersOrders = Array<Dictionary<String, Any>>()
    
    let segment: UISegmentedControl = UISegmentedControl(items: ["New", "Others"])
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Ahmed Othman"
        //self.navigationController?.title = "Ahmed Othman"

        let greenClr = UIColor.init(red: 59.0 / 255.0, green: 144.0 / 255.0, blue: 141 / 255.0, alpha: 1.0)
        
        self.tabBarController?.navigationController?.navigationBar.tintColor = greenClr
        self.tabBarController?.navigationItem.rightBarButtonItem = UIBarButtonItem(image: .actions, style: .plain, target: self, action: #selector(languagesAction))
        
        self.navigationController?.navigationBar.prefersLargeTitles = true
        
        segment.addTarget(self, action: #selector(segmentedCtrlChanged(sender:)), for: .valueChanged)
        segment.sizeToFit()
        segment.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin]
        if #available(iOS 13.0, *) {
            segment.selectedSegmentTintColor = greenClr
        } else {
            segment.tintColor = greenClr
        }
        segment.selectedSegmentIndex = 0
        let sgView = UIView(frame: CGRect(x: 0, y: 160, width: CGFloat((self.view?.frame.size.width)!), height: 40.0))
        sgView.backgroundColor = UIColor.clear
        sgView.clipsToBounds = true
        sgView.autoresizingMask = [.flexibleWidth]
        
        segment.center = CGPoint(x: sgView.frame.size.width / 2.0, y: sgView.frame.size.height / 2.0)
        sgView.addSubview(segment)
        //self.tabBarController?.view.addSubview(sgView)
        self.tabBarController!.navigationItem.titleView = sgView
        //segment.setTitleTextAttributes([NSAttributedString.Key.font : UIFont(name: "ProximaNova-Light", size: 15)!], for: .normal)
        //self.navigationController?.navigationItem.titleView = segment
        //self.tabBarController?.navigationItem.titleView = segment
        //self.tabBarController?.navigationItem.
        
        self.tabBarController?.tabBar.isHidden = true
        
//        let insets = UIEdgeInsets(top: 48.0, left: 0.0, bottom: 0.0, right: 0.0)
//        self.tableView.contentInset = insets
//        self.tableView.scrollIndicatorInsets = insets
        self.getOrders()
        
    }

    @objc func segmentedCtrlChanged(sender: UISegmentedControl) {
        if (sender.selectedSegmentIndex == 0) {
            self.tabBarController?.selectedIndex = 0
        } else {
            self.tabBarController?.selectedIndex = 1
        }
    }
    
    @objc func languagesAction(sender: UIBarButtonItem) {
        print(languagesAction)
    }
    
    
    func getOrders() {
        
        print("get Orders ")
        
        let url = URL(string: theURL + "OnyxDeliveryService/Service.svc/GetDeliveryBillsItems")!
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let message = MessageGetItems(
            P_DLVRY_NO: "1010",
            P_LANG_NO: "1",
            P_BILL_SRL: "",
            P_PRCSSD_FLG: ""
        )
        
        let msg = MessageGetItemsValue(Value: message)

        let data = try! JSONEncoder().encode(msg)

        print("data(post): " , String(data: data, encoding: .ascii) as Any)
        
        request.httpBody = data
        
        request.setValue(
            "application/json",
            forHTTPHeaderField: "Content-Type"
        )
        
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest, completionHandler: {

            data, response, error in

            guard let _:Data = data, let _:URLResponse = response  , error == nil else {
                return
            }
            
            print("res 0 " + String(data: data!, encoding: .utf8)!)

            let json: Any?

            do {
                json = try JSONSerialization.jsonObject(with: data!, options: [])
            }
            catch {
                return
            }
            
            print("res 1")
            guard let server_response = json as? NSDictionary else {
                return
            }

            print("res 2")
            
       
            
            guard let jsonData = server_response["Data"] as? Dictionary<String, Any> else {
                return
            }
        
            //let jsonDataIn = jsonData["Data"] as! Dictionary<String, Any>
            
            self.orders = jsonData["DeliveryBills"] as! Array<Dictionary<String, Any>>
            
            for order in self.orders {
                
                if (order["DLVRY_STATUS_FLG"] as? String == "0") {
                    self.newOrders.append(order)
                } else {
                    self.othersOrders.append(order)
                }
            }
            
            DispatchQueue.main.async { [weak self] in
                        
                
                if let othersOrdersNaviCtlr = self?.tabBarController?.viewControllers![1] as? UINavigationController {
                    
                    if let otherOrdersVC = othersOrdersNaviCtlr.viewControllers.first as? OrdersOthersViewController {
                        otherOrdersVC.othersOrders = self!.othersOrders
                    }
                    
                }
                
                self?.tableView.reloadData()
            }
                
            
            //
            
           
            
            
        }
        )

        task.resume()
        
    }

    
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return newOrders.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! OrdersTableViewCell
        
        let order = newOrders[indexPath.row]
        
        cell.orderNumberLbl?.text = "#" + (order["BILL_SRL"] as? String)!
        cell.statusLbl?.text = "New"
        cell.totalPriceLbl?.text = order["BILL_AMT"] as? String
        cell.dateLbl?.text = order["BILL_DATE"] as? String
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //self.performSegue(withIdentifier: "newsdetails_vc_segue", sender: self)
        
    }
    
}
