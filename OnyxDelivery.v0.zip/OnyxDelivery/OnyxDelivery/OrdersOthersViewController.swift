//
//  OrdersOthersViewController.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//



import UIKit

class OrdersOthersViewController: UITableViewController {
    
    let theURL: String = "https://mdev.yemensoft.net:473/"
    
    var othersOrders = Array<Dictionary<String, Any>>()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Ahmed Othman"
        self.navigationController?.navigationBar.prefersLargeTitles = true
        
        
//        let insets = UIEdgeInsets(top: 45.0, left: 0.0, bottom: 0.0, right: 0.0)
//        self.tableView.contentInset = insets
//        self.tableView.scrollIndicatorInsets = insets

                
//        let order1 = ["status": "Returned", "total_price": "6378 LE"]
//        orders.append(order1)
//        
//        let order2 = ["status": "Deliving", "total_price": "540 LE"]
//        orders.append(order2)
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        
//        if let newOrdersNaviCtlr = self.tabBarController?.viewControllers![0] as? UINavigationController {
//            
//            if let newOrdersVC = newOrdersNaviCtlr.viewControllers.first as? OrdersNewViewController {
//                self.othersOrders = newOrdersVC.othersOrders
//            }
//            
//        }
//        
//    }
    
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return self.othersOrders.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! OrdersTableViewCell
        
        let order = othersOrders[indexPath.row]
        
        cell.orderNumberLbl?.text = "#" + (order["BILL_SRL"] as? String)!
        cell.statusLbl?.text = "Delivered"
        cell.totalPriceLbl?.text = order["BILL_AMT"] as? String
        cell.dateLbl?.text = order["BILL_DATE"] as? String
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //self.performSegue(withIdentifier: "newsdetails_vc_segue", sender: self)
        
    }

}
