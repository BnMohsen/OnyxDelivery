//
//  LoginViewController.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//


import Foundation
import UIKit

struct MessageLoginValue: Encodable {

    let Value: MessageLogin
    
}

struct MessageLogin: Encodable {

    let P_DLVRY_NO: String
    let P_PSSWRD: String
    let P_LANG_NO: String
    
}


class LoginViewController: UIViewController {

    let theURL: String = "https://mdev.yemensoft.net:473/"
    //Textfields
    @IBOutlet weak var Username: UITextField!
    @IBOutlet weak var Password: UITextField!

    //Login Button
    @IBAction func LoginAction(_ sender: Any) {
        
        let chooseLanguageViewController = self.storyboard?.instantiateViewController(withIdentifier: "choose_language_vc_id")

//        self.present(chooseLanguageViewController!, animated: true, completion: {
//            
//        })
        //self.navigationController?.pushViewController(chooseLanguageViewController!, animated: true)
        login_now(username: Username.text!, password: Password.text!)

    }
    
    func login_now(username:String, password:String) {
   
        
        let url:URL = URL(string: theURL + "OnyxDeliveryService/Service.svc/CheckDeliveryLogin")!
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let message = MessageLogin(
            P_DLVRY_NO: "1010",
            P_PSSWRD: "1",
            P_LANG_NO: "1"
        )
        
        let msg = MessageLoginValue(Value: message)

        let data = try! JSONEncoder().encode(msg)

        print("data(post): " , String(data: data, encoding: .ascii) as Any)
        
        request.httpBody = data
        
        request.setValue(
            "application/json",
            forHTTPHeaderField: "Content-Type"
        )
        
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest, completionHandler: {

            data, response, error in

            guard let _:Data = data, let _:URLResponse = response  , error == nil else {
                return
            }
            
            print("res 0 " + String(data: data!, encoding: .utf8)!)

            let json: Any?

            do {
                json = try JSONSerialization.jsonObject(with: data!, options: [])
            }
            catch {
                return
            }
            
            print("res 1")
            guard let server_response = json as? NSDictionary else {
                return
            }

            print("res 2")
            
            DispatchQueue.main.async { [weak self] in
                 
                
                let chooseLanguageViewController = self?.storyboard?.instantiateViewController(withIdentifier: "choose_language_vc_id")
                self?.navigationController?.pushViewController(chooseLanguageViewController!, animated: true)
            }
        }
        )

        task.resume()
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Username.text = "1010"
        //Password.text = "1"
        
    
    }

    
}
