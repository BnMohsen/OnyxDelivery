//
//  OnyxDeliveryTests.swift
//  OnyxDeliveryTests
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//

import Testing
@testable import OnyxDelivery

struct OnyxDeliveryTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
