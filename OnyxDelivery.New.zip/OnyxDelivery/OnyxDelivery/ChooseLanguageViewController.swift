//
//  ChooseLanguageViewController.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//



import UIKit

class ChooseLanguageViewController: UIViewController {

    var selectedLanguage = 1
    
    @IBOutlet weak var chooseLanguageLbl: UILabel!
    @IBOutlet weak var ArabicBtn: UIButton!
    @IBOutlet weak var EnglishBtn: UIButton!
    @IBOutlet weak var ApplyBtn: UIButton!
    
    typealias CompletionHandler = (_ success:Bool) -> Void
    var callback: ((_ id: Int) -> Void)?
    
    let selectedClr = UIColor(red: (154.0/255.0), green: (227.0/255.0), blue: (154.0/255.0), alpha: 1.0)
    
    func methodName(completionBlock: () -> Void)  {

          print("block_Completion")
          completionBlock()
    }
    
    @IBAction func ArabicBtnAction(_ sender: Any) {
        self.selectedLanguage = 2
        self.updateButtonsState()
    }
    
    @IBAction func EnglishBtnAction(_ sender: Any) {
        self.selectedLanguage = 1
        self.updateButtonsState()
    }
    
    
    //Apply Button
    @IBAction func ApplyAction(_ sender: Any) {
        
        let ud = UserDefaults.standard
        ud.set(self.selectedLanguage, forKey: "UD_LANGUAGE_KEY")
        ud.synchronize()
        
        if (self.navigationController != nil) {
            let ordersTabBarController = self.storyboard?.instantiateViewController(withIdentifier: "orders_tabbar_controller_id")
            self.navigationController?.pushViewController(ordersTabBarController!, animated: true)
            self.navigationController?.viewControllers.remove(at: 1)
            
        } else {
            callback?(self.selectedLanguage)
            self.dismiss(animated: true)
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        self.selectedLanguage = UserDefaults.standard.integer(forKey: "UD_LANGUAGE_KEY")
        if (self.selectedLanguage == 0) {
            self.selectedLanguage = 1
        }
        
        self.updateButtonsState()
        
    }

    func updateButtonsState() {
        
        if (self.selectedLanguage == 1) {
            
            self.EnglishBtn.backgroundColor = self.selectedClr
            self.ArabicBtn.backgroundColor = UIColor.lightGray
            
            self.chooseLanguageLbl.text = "Choose Language"
            self.chooseLanguageLbl.textAlignment = .left
            self.EnglishBtn.setTitle("English", for: .normal)
            self.ArabicBtn.setTitle("Arabic", for: .normal)
            self.ApplyBtn.setTitle("Apply", for: .normal)
            
            if (self.navigationController != nil) {
                self.navigationItem.setLeftBarButton(UIBarButtonItem(title: "Back", style:.plain, target:self, action: #selector(backAction)), animated: true)
            }
            
        } else {
            
            self.EnglishBtn.backgroundColor = UIColor.lightGray
            self.ArabicBtn.backgroundColor = self.selectedClr
            
            self.chooseLanguageLbl.text = "اختر اللغة"
            self.chooseLanguageLbl.textAlignment = .right
            self.EnglishBtn.setTitle("الإنجليزية", for: .normal)
            self.ArabicBtn.setTitle("العربية", for: .normal)
            self.ApplyBtn.setTitle("تطبيق", for: .normal)
            
            if (self.navigationController != nil) {
                self.navigationItem.setLeftBarButton(UIBarButtonItem(title: "رجوع", style:.plain, target:self, action: #selector(backAction)), animated: true)
            }
            
        }
        
        
    }
    
    @objc func backAction(sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
