//
//  ViewController.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

