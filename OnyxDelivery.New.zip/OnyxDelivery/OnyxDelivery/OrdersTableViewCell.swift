//
//  OrdersTableViewCell.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//



import UIKit

class OrdersTableViewCell: UITableViewCell {
    @IBOutlet var containerView:UIView!
    
    @IBOutlet var statusTitleLbl:UILabel!
    @IBOutlet var totalPriceTitleLbl:UILabel!
    @IBOutlet var dateTitleLbl:UILabel!
    
    @IBOutlet var orderNumberLbl:UILabel!
    @IBOutlet var statusLbl:UILabel!
    @IBOutlet var totalPriceLbl:UILabel!
    @IBOutlet var dateLbl:UILabel!
    @IBOutlet var orderDetailsLbl:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        containerView.layer.cornerRadius = 2.0
    }
    
    func updateUI(selectedLang: Int) {
        
        if (selectedLang == 2) {
            
            self.statusTitleLbl.text = "حالة الطلب"
            self.totalPriceTitleLbl.text = "السعر الإجمالي"
            self.dateTitleLbl.text = "التاريخ"
            self.orderDetailsLbl.text = "تفاصيل الطلب                                               <"
            
        } else {
            
            self.statusTitleLbl.text = "Status"
            self.totalPriceTitleLbl.text = "Total Price"
            self.dateTitleLbl.text = "Date"
            self.orderDetailsLbl.text = "Order Details                                               >"
            
        }
        
    }
}
