//
//  LoginViewController.swift
//  OnyxDelivery
//
//  Created by Mohammed Al-Olofi on 17/02/2025.
//


import Foundation
import UIKit

struct MessageLoginValue: Encodable {

    let Value: MessageLogin
    
}

struct MessageLogin: Encodable {

    let P_DLVRY_NO: String
    let P_PSSWRD: String
    let P_LANG_NO: String
    
}


class LoginViewController: UIViewController {

    var selectedLanguage = 1
    let theURL: String = "https://mdev.yemensoft.net:473/"
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var subtitleLbl: UILabel!
    
    //Textfields
    @IBOutlet weak var Username: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var showMoreBtn: UIButton!

    //Login Button
    @IBAction func LoginAction(_ sender: Any) {
        
        //let chooseLanguageViewController = self.storyboard?.instantiateViewController(withIdentifier: "choose_language_vc_id")

        //self.present(chooseLanguageViewController!, animated: true, completion: {
            
        //})
        //self.navigationController?.pushViewController(chooseLanguageViewController!, animated: true)
        
        if ((Username.text!.isEmpty) || (Password.text!.isEmpty)) {
            let alert = UIAlertController(title: "Alert", message: "Fill All Text Fields!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        } else {
            login_now(username: Username.text!, password: Password.text!)
        }
        

    }
    
    func login_now(username:String, password:String) {
   
        
        let url:URL = URL(string: theURL + "OnyxDeliveryService/Service.svc/CheckDeliveryLogin")!
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let message = MessageLogin(
            P_DLVRY_NO: "1010",
            P_PSSWRD: "1",
            P_LANG_NO: "1"
        )
        
        let msg = MessageLoginValue(Value: message)

        let data = try! JSONEncoder().encode(msg)

        print("data(post): " , String(data: data, encoding: .ascii) as Any)
        
        request.httpBody = data
        
        request.setValue(
            "application/json",
            forHTTPHeaderField: "Content-Type"
        )
        
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest, completionHandler: {

            data, response, error in

            guard let _:Data = data, let _:URLResponse = response  , error == nil else {
                return
            }
            
            print("res 0 " + String(data: data!, encoding: .utf8)!)

            let json: Any?

            do {
                json = try JSONSerialization.jsonObject(with: data!, options: [])
            }
            catch {
                return
            }
            
            print("res 1")
            guard let server_response = json as? NSDictionary else {
                return
            }

            print("res 2")
            
       
            
            guard let jsonData = server_response["Data"] as? Dictionary<String, Any> else {
                return
            }
            
            print("jsonData ", jsonData)
            
            let deliveryName = jsonData["DeliveryName"] as! String
            
            print("deliveryName ", deliveryName)
            
            let ud = UserDefaults.standard
            ud.set(deliveryName, forKey: "UD_DELIVERY_NAME_KEY")
            ud.synchronize()
            
            DispatchQueue.main.async { [weak self] in
                 
                if (UserDefaults.standard.integer(forKey: "UD_LANGUAGE_KEY") == 0) {
                    
                    let chooseLanguageViewController = self?.storyboard?.instantiateViewController(withIdentifier: "choose_language_vc_id")
                    self?.navigationController?.pushViewController(chooseLanguageViewController!, animated: true)
                    
                } else {
                    
                    let ordersTabBarController = self?.storyboard?.instantiateViewController(withIdentifier: "orders_tabbar_controller_id")

                    self?.navigationController?.pushViewController(ordersTabBarController!, animated: true)
                    
                }
                
            }
        }
        )

        task.resume()
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Username.text = "1010"
        //Password.text = "1"
    
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.selectedLanguage = UserDefaults.standard.integer(forKey: "UD_LANGUAGE_KEY")
        if (self.selectedLanguage == 0) {
            self.selectedLanguage = 1
        }
        
        self.updateUILang()
        
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        Username.text = ""
        Password.text = ""
    }
    
    func updateUILang() {
        
        if (self.selectedLanguage == 1) {
            
            self.titleLbl.text = "Welcome Back!"
            self.subtitleLbl.text = "Log Back into your account"
            
            self.Username.placeholder = "User ID"
            self.Password.placeholder = "Password"
            
            self.loginBtn.setTitle("Login", for: .normal)
            self.showMoreBtn.setTitle("Show More", for: .normal)
            
        } else if (self.selectedLanguage == 2) {
            
            self.titleLbl.text = "مرحبا بك مرة أخرى!"
            self.subtitleLbl.text = "سجل دخول إلى حسابك مجدداً"
            
            self.Username.placeholder = "اسم المستخدم"
            self.Password.placeholder = "كلمة المرور"
            
            self.loginBtn.setTitle("دخول", for: .normal)
            self.showMoreBtn.setTitle("إظهار المزيد", for: .normal)
            
        }
        
        let greenClr = UIColor.init(red: 59.0 / 255.0, green: 144.0 / 255.0, blue: 141 / 255.0, alpha: 1.0)
        self.showMoreBtn.setTitleColor(greenClr, for: .normal)
    }
    
}
